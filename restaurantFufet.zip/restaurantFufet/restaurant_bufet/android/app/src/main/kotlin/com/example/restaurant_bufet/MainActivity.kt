package com.example.restaurant_bufet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
