import 'package:flutter/material.dart';

class PantallaInicio extends StatefulWidget {
  @override
  _PantallaInicioState createState() => _PantallaInicioState();
}

class _PantallaInicioState extends State<PantallaInicio> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: <Widget>[
            Column(
              children: <Widget>[
                Center(
                  child: Image.asset("assets/img/descarga.jpg",
                    width: MediaQuery.of(context).size.width/2,
                    height: 200,
                  ),

                ),
                MaterialButton(
                  minWidth: 200.0,
                  height: 40.0,
                  onPressed: () {},
                  color: Colors.lightBlue,
                  child: const Text('Material Button', style: TextStyle(color: Colors.white)),
                ),
              ]
            )

          ]
        ),
      ),
    );
 }
}